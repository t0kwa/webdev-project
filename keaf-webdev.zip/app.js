$(document).ready(function() {
    $(".bubble").on("click", function() {
        const desc = "Data type- Different storages for each type of toys. Int - Stores toys with numbers written on it.";
        $("#topic").html(desc);
    })
});



